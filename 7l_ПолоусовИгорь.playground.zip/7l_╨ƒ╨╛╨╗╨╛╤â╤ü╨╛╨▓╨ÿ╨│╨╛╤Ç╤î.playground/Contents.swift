import Cocoa
import Foundation

/*
 1. Придумать класс, методы которого могут завершаться неудачей и возвращать либо значение, либо ошибку Error?. Реализовать их вызов и обработать результат метода при помощи конструкции if let, или guard let.

 2. Придумать класс, методы которого могут выбрасывать ошибки. Реализуйте несколько throws-функций. Вызовите их и обработайте результат вызова при помощи конструкции try/catch.
 */


// Задание 1

// задали названия производителей банкоматов
enum ATMBrand: String {
    case wincoreNixdorf = "WincoreNixdorf"
    case ncr = "NCR"
    case nautilusHyosung = "NautilusHyosung"
}
// задали виды банкоматов
enum FunctionATM: String{
    case cashOutOnly = "Только выдача наличных и проверка баланса счёта"
    case multiFunction = " Выдача и внесение наличных, проверка баланса"
    case recycling = "Прием и выдача наличных внесенных ранее клиентами "
}
// задали функции банкоматов
enum Errors: String{
    case cashOutOnly = "Только выдача наличных, воспользуйтесь банкоматом с функцией приема наличных"
    case outOfService = "Нет приема или выдачи наличных, только баланс"
    case insufficientFunds = "Недостаточно средств на счете"
    case outOfCash = "В банкомате закончились наличные"
    case wrongPIN = "ПИН код введен неверно"
}

enum CustomerChoice: String {
    case cashIn = "Внесение"
    case cashOut = "Снятие"
    case balance = "Баланс"
}


class ATM {
    var brand: ATMBrand
    var atmFunction: FunctionATM
    var cashInsideLeft: Int
    var customerBalance: Int
    
    init(brand: ATMBrand, atmFunction: FunctionATM, cashInsideLeft: Int) {
        self.brand = brand
        self.atmFunction = atmFunction
        self.cashInsideLeft = cashInsideLeft
        self.customerBalance = 2000
        }
    
    let pin = 1234 // ПИН код
    
    // выдача, снятие наличных, посмотреть баланс счёта
    func service (enter PIN: Int, servChoice: CustomerChoice, amount: Int) {
        guard PIN == pin else {
            print(Errors.wrongPIN.rawValue)
            return
        }
        if servChoice == .balance{
            print("Ваш баланс: \(customerBalance)")
        }
        if servChoice == .cashIn {
            guard atmFunction != .cashOutOnly else {
                print(Errors.cashOutOnly.rawValue)
                return
            }
            cashInsideLeft += amount
            customerBalance += amount
        }
        if servChoice == .cashOut {
            guard customerBalance >= amount else {
                print(Errors.insufficientFunds.rawValue)
                return
            }
            
            guard cashInsideLeft >= amount else {
                print(Errors.outOfCash.rawValue)
                return
            }
            cashInsideLeft -= amount
            customerBalance -= amount
        }
    }
    func balance(){
        print("Ваш баланс: \(customerBalance)") //  баланс
    }
}
    
extension ATM: CustomStringConvertible{
    var description: String{
        return """

                Производитель банкомата: \(brand.rawValue)
                Функции банкомата:       \(atmFunction.rawValue)
                Денег в банкомате:       \(cashInsideLeft)

               """
    }
}
var test = ATM(brand: .nautilusHyosung, atmFunction: .cashOutOnly, cashInsideLeft: 1800)
print(test)
test.service(enter: 1234, servChoice: .cashIn, amount: 120) // не понял как сделать так чтобы значение amount можно было ввести только если servChoice != .balance

// Задание 2
enum CheckPin: Error {
    case wrongPin
    
    var selfDescription: String {
        switch self {
        case .wrongPin:
            return "Введен неправильный пин код"
        }
    }
}
// расширение проверки баланса
extension ATM {
    func checkBalance(PIN: Int) throws -> Int {
        guard PIN == pin else {
            throw CheckPin.wrongPin
        }
    return customerBalance
    }
}

do {
    let tru1 = try test.checkBalance(PIN: 1234)
    print("\nБаланс равен: \(tru1)")
        
} catch CheckPin.wrongPin {
    print("\nВы ввели неправильный пин код. Попробуйте ещё раз")
    
} catch let error {
    print(error)
}
