import Cocoa

/*
 1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.

 2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример: filter для массивов)

 3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.
 */


// задали названия производителей банкоматов
enum ATMBrand: String {
    case wincoreNixdorf = "WincoreNixdorf"
    case ncr = "NCR"
    case nautilusHyosung = "NautilusHyosung"
}
enum FunctionATM: String{
    case cashOutOnly = "Только выдача наличных и проверка баланса счёта"
    case multiFunction = " Выдача и внесение наличных, проверка баланса"
    case recycling = "Прием и выдача наличных внесенных ранее клиентами "
}

// создали класс Банкоматы ATM

class ATM {
    var brand: ATMBrand
    var atmFunction: FunctionATM
    var cashInsideLeft: Int
    
    init(brand:ATMBrand, atmFunction: FunctionATM, cashInsideLeft: Int) {
        self.brand = brand
        self.atmFunction = atmFunction
        self.cashInsideLeft = cashInsideLeft
        }
}


//var testATM = ATM(brand: .ncr, atmFunction: .cashOutOnly, cashInsideLeft: 1200)
//print(testATM)

// структура Generic
struct GenericStack <Y>{
    var elements:[Y] = []
    
    func filter(predicate: (Y) -> Bool) -> [Y] {
        var tempArray: [Y] = []
        for element in elements{
            if predicate(element) {
                tempArray.append(element)
            }
        }
            return tempArray
    }

    mutating func push(_ element: Y){
        elements.append(element)
    }
    
    mutating func pop() -> Y?{
        guard elements.count > 0 else {return nil}
        return elements.removeFirst()
    }
}

extension ATM: CustomStringConvertible {
    var description: String {
        return """
                   
                   ATM Brand: \(brand)
                   Выполняемые функции: \(atmFunction)

                   """
    }
}


// тестовая структура
var sberATMS = GenericStack<ATM>()


sberATMS.push(ATM(brand: .wincoreNixdorf, atmFunction: .cashOutOnly, cashInsideLeft: 300))
sberATMS.push(ATM(brand: .nautilusHyosung, atmFunction: .recycling, cashInsideLeft: 1200))
sberATMS.push(ATM(brand: .ncr, atmFunction: .multiFunction, cashInsideLeft: 300))
sberATMS.push(ATM(brand: .wincoreNixdorf, atmFunction: .cashOutOnly, cashInsideLeft: 450))
sberATMS.push(ATM(brand: .nautilusHyosung, atmFunction: .cashOutOnly, cashInsideLeft: 2300))

//print(sberATMS.elements)

sberATMS.pop()

//print(sberATMS.elements)

extension GenericStack {
    
    subscript (index: Int) -> Y?{
        guard index >= 0 && index < elements.count else {
            return nil
        }
        return elements[index]
    }
}

var sberATMsFilter = sberATMS.filter() {element in element.atmFunction == .cashOutOnly}
sberATMsFilter.forEach { print($0.description)}

print(sberATMS[8])


