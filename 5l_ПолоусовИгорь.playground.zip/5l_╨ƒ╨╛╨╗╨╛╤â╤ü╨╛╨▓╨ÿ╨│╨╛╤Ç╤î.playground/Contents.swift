import Foundation
import Cocoa

// Доставили  device, теперь файлы с ДЗ будут в нужном формате. Спасибо)

/*
 1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.

2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).

3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.

4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.

5. Создать несколько объектов каждого класса. Применить к ним различные действия.

6. Вывести сами объекты в консоль.
*/


//Задание 1. Создать протокол "Car"
 
protocol Car {
    var carBrend: CarBrend { get }
    var productionYear: Int { get }
    var fuelType: FuelType.RawValue { get }
    var wheelDrive: WheelDrive.RawValue { get }
    var km: Int { get }
    var transmissionType: TransmissionType.RawValue { get }
    var tintedGlass: TintedGlass.RawValue { get }
    var windGlassHeat: Bool { get }
    var stearingWheelHeat:Bool { get }
    var seatsHeat: Bool { get }
    var frontPassengerAirBag: FrontPassengerAirBag.RawValue { get }
    var engineStatus: EngineStatus.RawValue { get }
    var windowsState: WindowsState.RawValue{ get }
    var parkingLights: ParkingLights.RawValue { get }
    var dippedHeadLights:DippedHeadlights.RawValue{ get }
    
    func addRemoveTintedGlass(_ done:TintedGlass)
    func addKm(_ addKm:Int)
}
 

// Задание 2. Создать расширения
  
extension Car {
    func startStopEngine(_ done: EngineStatus){}
    func windowsState(_ done: WindowsState){}
    func ParkingLights(_ done: ParkingLights){}
    func DippedHeadLights(_ done: DippedHeadlights){}
    func FrontPassangerAirBag(_ done: FrontPassengerAirBag){}
}

enum TransmissionType: String {
    case auto = "Автоматическая коробка передач"
    case manual = "Механическая коробка передач"
}
enum CarType {
    case sedan, crossover, wagon
}
enum WheelDrive: String{
    case front = "Передний привод"
    case rear = "Задний привод"
    case all = "Полный привод"
}
enum FuelType:String {
    case diesel = "Дизельное топливо"
    case gasoline = "Бензин"
}
enum CarBrend: String {
    case BMW, Volvo
}
enum EngineStatus: String{
    case start = "Двигатель запущен"
    case stop = "Двигатель остановлен"
}
enum WindowsState: String {
    case closed = "Окна закрыты"
    case opened = "Окна открыты"
}

enum ParkingLights: String {
    case on = "Габаритные огни включены"
    case off = "Габаритные огни отключены"
}

enum DippedHeadlights: String {
    case on = "Ближний свет включен"
    case off = "Ближний свет отключен"
}

enum FrontPassengerAirBag: String {
    case on = "Подушка безопасности переднего пассажира включена"
    case off = "Подушка безопасности переднего пассажира отключена"
}
enum TintedGlass: String {
    case yes = "Автомобиль затонирован"
    case no = "Автомобиль без тонировки"
}
    
// Задание 3. Создать два класса TrunkCar  и SportCar.

 class TrunkCar: Car {
    var tankVolume: Int // свойство класса trunkCar
    var carBrend: CarBrend
    var productionYear: Int
    var fuelType: FuelType.RawValue
    var wheelDrive: WheelDrive.RawValue
    var km: Int
    var transmissionType: TransmissionType.RawValue
    var tintedGlass: TintedGlass.RawValue
    var windGlassHeat: Bool
    var stearingWheelHeat: Bool
    var seatsHeat: Bool
    var frontPassengerAirBag: FrontPassengerAirBag.RawValue
    var engineStatus: EngineStatus.RawValue
    var windowsState: WindowsState.RawValue
    var dippedHeadLights: DippedHeadlights.RawValue
    var parkingLights: ParkingLights.RawValue
        
    init(tankVolume: Int, carBrend: CarBrend, productionYear: Int, fuelType: FuelType, wheelDrive: WheelDrive, km: Int, transmissionType: TransmissionType, tintedGlass: TintedGlass, windGlassHeat: Bool, stearingWheelHeat: Bool, seatsHeat: Bool, frontPassengerAirBag: FrontPassengerAirBag, engineStatus: EngineStatus, windowsState: WindowsState, parkingLights: ParkingLights,dippedHeadLights: DippedHeadlights) {
        self.tankVolume = tankVolume
        self.carBrend = carBrend
        self.productionYear = productionYear
        self.fuelType = fuelType.rawValue
        self.wheelDrive = wheelDrive.rawValue
        self.km = km
        self.transmissionType = transmissionType.rawValue
        self.tintedGlass = tintedGlass.rawValue
        self.windGlassHeat = windGlassHeat
        self.stearingWheelHeat = stearingWheelHeat
        self.seatsHeat = seatsHeat
        self.frontPassengerAirBag =  frontPassengerAirBag.rawValue
        self.engineStatus = engineStatus.rawValue
        self.windowsState = windowsState.rawValue
        self.parkingLights = parkingLights.rawValue
        self.dippedHeadLights = dippedHeadLights.rawValue
    }
    
    func addRemoveTintedGlass(_ done:TintedGlass) {
        tintedGlass = done.rawValue
    }
    
    func addKm(_ addKm:Int){
        km = km + addKm
    }
    
    func startStopEngine(_ done: EngineStatus){
            engineStatus = done.rawValue
    }
    
    func windowsState(_ done: WindowsState){
            windowsState = done.rawValue
    }
    
    func ParkingLights(_ done: ParkingLights){
            parkingLights = done.rawValue
    }
    
    func DippedHeadLights(_ done: DippedHeadlights){
            dippedHeadLights = done.rawValue
    }
    
    func FrontPassangerAirBag(_ done: FrontPassengerAirBag){
            frontPassengerAirBag = done.rawValue
    }
}

class SportCar: Car{
    var carType: CarType // Свойство класса SportCar
    var trunkSize: Int   // Свойство класса SportCar
    var carBrend: CarBrend
    var productionYear: Int
    var fuelType: FuelType.RawValue
    var wheelDrive: WheelDrive.RawValue
    var km: Int
    var transmissionType: TransmissionType.RawValue
    var tintedGlass: TintedGlass.RawValue
    var windGlassHeat: Bool
    var stearingWheelHeat: Bool
    var seatsHeat: Bool
    var frontPassengerAirBag: FrontPassengerAirBag.RawValue
    var engineStatus: EngineStatus.RawValue
    var windowsState: WindowsState.RawValue
    var parkingLights: ParkingLights.RawValue
    var dippedHeadLights: DippedHeadlights.RawValue
    
    init(carType: CarType, trunkSize: Int, carBrend: CarBrend, productionYear: Int, fuelType: FuelType, wheelDrive: WheelDrive, km: Int, transmissionType: TransmissionType, tintedGlass: TintedGlass, windGlassHeat: Bool, stearingWheelHeat: Bool, seatsHeat: Bool, frontPassengerAirBag: FrontPassengerAirBag, engineStatus: EngineStatus, windowsState: WindowsState, parkingLights: ParkingLights,dippedHeadLights: DippedHeadlights ) {
        self.carType = carType
        self.trunkSize = trunkSize
        self.carBrend = carBrend
        self.productionYear = productionYear
        self.fuelType = fuelType.rawValue
        self.wheelDrive = wheelDrive.rawValue
        self.km = km
        self.transmissionType = transmissionType.rawValue
        self.tintedGlass = tintedGlass.rawValue
        self.windGlassHeat = windGlassHeat
        self.stearingWheelHeat = stearingWheelHeat
        self.seatsHeat = seatsHeat
        self.frontPassengerAirBag =  frontPassengerAirBag.rawValue
        self.engineStatus = engineStatus.rawValue
        self.windowsState = windowsState.rawValue
        self.parkingLights = parkingLights.rawValue
        self.dippedHeadLights = dippedHeadLights.rawValue
     }
   
    func addRemoveTintedGlass(_ done:TintedGlass) {
        tintedGlass = done.rawValue
    }
    
    func addKm(_ addKm:Int){
        km = km + addKm
    }
    
    func startStopEngine(_ done: EngineStatus){
            engineStatus = done.rawValue
    }
    
    func windowsState(_ done: WindowsState){
            windowsState = done.rawValue
    }
    
    func ParkingLights(_ done: ParkingLights){
            parkingLights = done.rawValue
    }
    
    func DippedHeadLights(_ done: DippedHeadlights){
            dippedHeadLights = done.rawValue
    }
    
    func FrontPassangerAirBag(_ done: FrontPassengerAirBag){
            frontPassengerAirBag = done.rawValue
    }
}


// Задание 4.
 
extension TrunkCar: CustomStringConvertible {
    var description: String {
        let checkWindGlassHeat = windGlassHeat ? "Есть подогрев лобового стекла" : "Без подогрева лобового стекла"
        let checkStearingWheelHeat = stearingWheelHeat ? "Есть подогрев руля" : "Без подогрева руля"
        let checkSeatHeat = seatsHeat ? "Есть подогрев сидений" : "Без подогрева сидений"
        return """
                \n Объём бочки: \(tankVolume)
                Марка автомобиля: \(carBrend)
                Год выпуска: \(productionYear)
                Тип топлива: \(fuelType)
                Привод автомобиля: \(wheelDrive)
                Пробег: \(km)
                Тип коробки передач: \(transmissionType)
                Тонировка: \(tintedGlass)
                Подогрев лобового стекла: \(checkWindGlassHeat)
                Подогрев руля: \(checkStearingWheelHeat)
                Подогрев сидений: \(checkSeatHeat)
                Подушка безопасности переднего пассажира: \(frontPassengerAirBag)
                Статус двигателя: \(engineStatus)
                Статус окон: \(windowsState)
                Габаритные огни: \(parkingLights)
                Ближний свет: \(dippedHeadLights)
               """
    }
    func printDescription(){
        print(description)
    }
}

extension SportCar: CustomStringConvertible {
    var description: String {
        let checkWindGlassHeat = windGlassHeat ? "Есть подогрев лобового стекла" : "Без подогрева лобового стекла"
        let checkStearingWheelHeat = stearingWheelHeat ? "Есть подогрев руля" : "Без подогрева руля"
        let checkSeatHeat = seatsHeat ? "Есть подогрев сидений" : "Без подогрева сидений"
        return """
                \nТип кузова: \(carType)
                Размер багажника: \(trunkSize)
                Марка автомобиля: \(carBrend)
                Год выпуска: \(productionYear)
                Тип топлива: \(fuelType)
                Привод автомобиля: \(wheelDrive)
                Пробег: \(km)
                Тип коробки передач: \(transmissionType)
                Тонировка: \(tintedGlass)
                Подогрев лобового стекла: \(checkWindGlassHeat)
                Подогрев руля: \(checkStearingWheelHeat)
                Подогрев сидений: \(checkSeatHeat)
                Подушка безопасности переднего пассажира: \(frontPassengerAirBag)
                Статус двигателя: \(engineStatus)
                Статус окон: \(windowsState)
                Габаритные огни: \(parkingLights)
                Ближний свет: \(dippedHeadLights)
               """
    
    }
    func printDescription(){
        print(description)
    }
}



// Задание 5.

let trunkCar1 = TrunkCar(tankVolume: 1000, carBrend: .Volvo, productionYear: 2020, fuelType: .diesel, wheelDrive: .rear, km: 1250, transmissionType: .auto, tintedGlass: .no, windGlassHeat: true, stearingWheelHeat: true, seatsHeat: true, frontPassengerAirBag: .off, engineStatus: .start, windowsState: .closed, parkingLights: .on, dippedHeadLights: .on)
let trunkCar2 = TrunkCar(tankVolume: 1400, carBrend: .Volvo, productionYear: 2019, fuelType: .diesel, wheelDrive: .rear, km: 1567, transmissionType: .manual, tintedGlass: .yes, windGlassHeat: true, stearingWheelHeat: true, seatsHeat: true, frontPassengerAirBag: .off, engineStatus: .stop, windowsState: .closed, parkingLights: .on, dippedHeadLights: .off)

trunkCar1.addRemoveTintedGlass(.no)
trunkCar1.addKm(1234)
trunkCar1.DippedHeadLights(.off)


trunkCar2.DippedHeadLights(.off)
trunkCar2.FrontPassangerAirBag(.off)
trunkCar2.addRemoveTintedGlass(.no)

let sportCar1 = SportCar(carType: .crossover, trunkSize: 500, carBrend: .BMW, productionYear: 2021, fuelType: .diesel, wheelDrive: .all, km: 1230, transmissionType: .auto, tintedGlass: .yes, windGlassHeat: true, stearingWheelHeat: true, seatsHeat: true, frontPassengerAirBag: .on, engineStatus: .start, windowsState: .closed, parkingLights: .on, dippedHeadLights: .off)

let sportCar2 = SportCar(carType: .sedan, trunkSize: 1000, carBrend: .BMW, productionYear: 2017, fuelType: .gasoline, wheelDrive: .front, km: 56000, transmissionType: .manual, tintedGlass: .no, windGlassHeat: true, stearingWheelHeat: false, seatsHeat: false, frontPassengerAirBag: .on, engineStatus: .stop, windowsState: .closed, parkingLights: .off, dippedHeadLights: .on)

sportCar1.DippedHeadLights(.off)
sportCar2.FrontPassangerAirBag(.off)
sportCar1.addKm(14560)
sportCar2.addRemoveTintedGlass(.no)

// Задание 6.
 
trunkCar1.printDescription()
trunkCar2.printDescription()

sportCar1.printDescription()
sportCar2.printDescription()
